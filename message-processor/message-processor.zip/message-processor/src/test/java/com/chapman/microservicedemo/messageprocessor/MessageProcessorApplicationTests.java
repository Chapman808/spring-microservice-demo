package com.chapman.microservicedemo.messageprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
