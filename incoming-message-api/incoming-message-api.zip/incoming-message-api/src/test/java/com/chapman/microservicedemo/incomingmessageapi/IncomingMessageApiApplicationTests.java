package com.chapman.microservicedemo.incomingmessageapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncomingMessageApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
